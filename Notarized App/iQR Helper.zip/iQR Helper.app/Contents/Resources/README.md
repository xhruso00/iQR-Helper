# iQR Helper for Dynamic QR Codes

Just run the notarized app from zip file https://github.com/xhruso00/iQR-Helper/releases/tag/1.0

![logo](https://github.com/xhruso00/iQR-Helper/blob/master/iQRHelper.png)

